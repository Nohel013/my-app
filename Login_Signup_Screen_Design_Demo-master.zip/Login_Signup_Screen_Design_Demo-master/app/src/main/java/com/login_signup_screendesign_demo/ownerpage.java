package com.login_signup_screendesign_demo;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class ownerpage extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ownerpage);
    }
}
