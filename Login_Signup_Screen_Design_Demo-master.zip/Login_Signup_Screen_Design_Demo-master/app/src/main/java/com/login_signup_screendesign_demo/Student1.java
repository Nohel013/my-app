package com.login_signup_screendesign_demo;


import android.widget.EditText;

public class Student1 {


    private String fullname1;
    private String emailId1;
    private String mobile1;
    private String locat1;
    private String pass1;
    private String conf1;




    public Student1(String fullname, String emailId, String mobile, String locat, String pass, String conf) {
        this.fullname1 = fullname;
        this.emailId1 = emailId;
        this.mobile1 = mobile;
        this.locat1 = locat;
        this.pass1 = pass;
        this.conf1 = conf;

    }




    public String getFullname1() {
        return fullname1;
    }

    public void setFullname1(String fullname1) {
        this.fullname1 = fullname1;
    }

    public String getEmailId1() {
        return emailId1;
    }

    public void setEmailId1(String emailId1) {
        this.emailId1 = emailId1;
    }

    public String getMobile1() {
        return mobile1;
    }

    public void setMobile1(String mobile1) {
        this.mobile1 = mobile1;
    }

    public String getLocat1() {
        return locat1;
    }

    public void setLocat1(String locat1) {
        this.locat1 = locat1;
    }

    public String getPass1() {
        return pass1;
    }

    public void setPass1(String pass1) {
        this.pass1 = pass1;
    }

    public String getConf1() {
        return conf1;
    }

    public void setConf1(String conf1) {
        this.conf1 = conf1;
    }
}
